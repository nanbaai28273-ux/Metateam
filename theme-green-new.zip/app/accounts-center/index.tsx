import Notification from '#components/meta/Notification'
import React from 'react'

const AccountsCenter = () => {
    return (
        <>
            <Notification/>
        </>
    )
}

export default AccountsCenter