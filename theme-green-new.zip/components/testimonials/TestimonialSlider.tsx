"use client";

import useEmblaCarousel from "embla-carousel-react";
import { useEffect, useState } from "react";

interface Testimonial {
    content: string;
    name: string;
}

const data: Testimonial[] = [
    {
        content: "After enrolling in Meta Verified, I noticed increased reach on my posts and higher engagement with my audience. I think that seeing a verified badge builds trust. People that I don't know or newer brands interested in working with me can make sure that they're talking with me and not a scammer.",
        name: "Kimber Greenwood, Owner of Water Bear Photography",
    },
    {
        content: "Since subscribing, I've noticed a real difference. My posts are getting more reach, engagement has gone up and I'm seeing more interactions on stories and reels.",
        name: "Devon Kirby, Owner, Mom Approved Miami",
    },
    {
        content: "Having a verified account signals to both our existing followers and new visitors that we are a credible, professional business that takes both our products and social presence seriously.",
        name: "Sarah Clancy, Owner of Sarah Marie Running Co.",
    },
];

export default function TestimonialSlider() {

    const [emblaRef, emblaApi] = useEmblaCarousel({ loop: true });
    const [selected, setSelected] = useState(0);

    useEffect(() => {
        if (!emblaApi) return;
        const onSelect = () => setSelected(emblaApi.selectedScrollSnap());
        emblaApi.on("select", onSelect);
        onSelect();
    }, [emblaApi]);

    return (
        <div className="max-w-[1175px] mx-auto px-6 mb-[80px]">
            <p className='text-center md:text-[32px] text-[24px] mb-10'>See how Meta Verified has helped real businesses.</p>
            <div className="bg-[#f1f4f7] overflow-hidden rounded-[24px]" ref={emblaRef}>
                <div className="flex">
                    {data.map((item, i) => (
                        <div
                            key={i}
                            className="flex-[0_0_100%] py-20 md:px-20 px-4"
                        >
                            <div className="text-center h-full flex flex-col justify-center items-center">
                                <p className="md:text-[24px] text-[17px] font-[300] mb-8">“{item.content}”</p>
                                <p className="md:text-[18px] text-[15px] font-helvetica font-[100] md:px-[25%] px-4">{item.name}</p>
                            </div>
                        </div>
                    ))}
                </div>
            </div>

            {/* Pagination Row */}
            <div className="flex items-center justify-center gap-8 mt-6">
                <button
                    onClick={() => emblaApi?.scrollPrev()}
                    className="w-[32px] h-[32px] md:block hidden"
                >
                    <img src="/images/meta/ic_left.svg" alt="left" className="w-[32px] h-[32px]" />
                </button>

                <div className="flex gap-2">
                    {data.map((_, i) => (
                        <button
                            key={i}
                            onClick={() => emblaApi?.scrollTo(i)}
                            className={`w-[10px] h-[10px] rounded-full ${selected === i
                                    ? "bg-gray-900"
                                    : "bg-gray-300"
                                }`}
                        />
                    ))}
                </div>

                <button
                    onClick={() => emblaApi?.scrollNext()}
                    className="w-[32px] h-[32px] md:block hidden"
                >
                    <img src="/images/meta/ic_right.svg" alt="right" className="w-[32px] h-[32px]" />
                </button>

            </div>
        </div>
    );
}
