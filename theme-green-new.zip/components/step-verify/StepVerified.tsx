import Link from 'next/link'
import React from 'react'

const StepVerified = () => {
    return (
        <div className='bg-[url(/images/meta/bg_step_verified.jpg)] bg-cover bg-center bg-no-repeat my-20'>
            <div className='max-w-[1175px] mx-auto md:py-20 py-10 px-6 mb-[80px]'>
                <div className='w-[100%]'>
                    <p className='text-[32px]'>Sign up for Meta Verified.</p>
                    <p className='text-[16px] text-[#1c2b33] font-[300] my-4'>Our verification process is designed to maintain the integrity of the verified badge for businesses. Let&apos;s start by confirming our invitation.</p>
                    <div className='grid grid-cols-12 gap-4 pt-12'>
                        <div className='md:col-span-4 col-span-12 border border-[#cbd2d9] rounded-[24px] bg-white p-10'>
                            <img src="/images/meta/one.png" alt="step_verified_1" className='w-[56px] h-[56px] mb-4 min-w-[56px] min-h-[56px]' />
                            <h3 className="text-[24px] font-[300]">Start your application.</h3>
                            <p className='mt-3 text-[14px] text-[#465A69] font-[100]'>Those interested in applying for Meta Verified will need to register and meet certain eligibility requirements (<Link className='underline decoration-[#cbd2d9]' href="https://www.facebook.com/business/help/1980422732333373?id=579726174359330">requirements for facebook</Link>). We are pleased to see that your business is one of the few that we have considered and selected.</p>
                        </div>
                        <div className='md:col-span-4 col-span-12 border border-[#cbd2d9] rounded-[24px] bg-white p-10'>
                            <img src="/images/meta/two.png" alt="step_verified_1" className='w-[56px] h-[56px] mb-4 min-w-[56px] min-h-[56px]' />
                            <h3 className="text-[24px] font-[300]">Verify business details.</h3>
                            <p className='mt-3 text-[14px] text-[#465A69] font-[100]'>You may be asked to share details such as your business name, address, website and/or phone number.</p>
                        </div>
                        <div className='md:col-span-4 col-span-12 border border-[#cbd2d9] rounded-[24px] bg-white p-10'>
                            <img src="/images/meta/three.png" alt="step_verified_1" className='w-[56px] h-[56px] mb-4 min-w-[56px] min-h-[56px]' />
                            <h3 className="text-[24px] font-[300]">Get feedback.</h3>
                            <p className='mt-3 text-[14px] text-[#465A69] font-[100]'>We&apos;ll review your application and send an update on your status within three working days.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default StepVerified
