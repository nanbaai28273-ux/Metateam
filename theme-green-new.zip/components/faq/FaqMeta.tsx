"use client"

import Link from 'next/link'
import React, { useState } from 'react'

interface FaqItem {
    question: string;
    answer: React.ReactNode;
}

const faqData: FaqItem[] = [
    {
        question: "How do I know if my business is eligible?",
        answer: (
            <>
                Meta Verified is available in selected regions for businesses that meet certain eligibility requirements (<Link className='text-[#0064E0] underline decoration-[#cbd2d9]' href="https://www.facebook.com/business/help/2876154822522394">requirements for Facebook and Instagram</Link>; <Link className='text-[#0064E0] underline decoration-[#cbd2d9]' href="https://faq.whatsapp.com/3872729742954601">requirements for WhatsApp</Link>).
            </>
        ),
    },
    {
        question: "How can I stay informed if I'm not yet eligible?",
        answer: (
            <>
                <Link className='text-[#0064E0] underline decoration-[#cbd2d9]' href="https://business.facebook.com/business/loginpage">Join our waitlist </Link> to stay updated. We will notify you when Meta Verified for businesses is available. Joining the waiting list does not guarantee early access to Meta Verified. <br />
            </>
        ),
    },
    {
        question: "I already have a verified badge. What happens to it?",
        answer: (
            <>
                No action is needed in order to keep your badge. Existing verified badge holders can apply for a Meta Verified subscription to access additional benefits if they meet the eligibility requirements (<Link className='text-[#0064E0] underline decoration-[#cbd2d9]' href="https://www.facebook.com/business/help/2876154822522394">requirements for Facebook and Instagram</Link>; <Link className='text-[#0064E0] underline decoration-[#cbd2d9]' href="https://faq.whatsapp.com/3872729742954601">requirements for WhatsApp</Link>).
            </>
        ),
    },
    {
        question: "What if I am interested in Meta Verified for creators?",
        answer: (
            <>
                You can learn more and sign up on the (<Link className='text-[#0064E0] underline decoration-[#cbd2d9]' href="">Meta Verified for creators website.</Link>).
            </>
        ),
    },
    {
        question: "Where will my badge appear?",
        answer: "If you select a Facebook asset as part of your subscription, your Facebook Page and Messenger account will display a verified badge. If you select an Instagram asset as part of your subscription, your Instagram and Threads accounts will display a verified badge. If you select a WhatsApp asset as part of your subscription, your WhatsApp business profile, chat header and channel will display a verified badge. Additional benefits of Meta Verified are not yet available on Threads or Messenger.",
    },
    {
        question: "What determines which plans are available to me?",
        answer: "Meta determines plan availability based on your business activity on our apps which, depending on your region and the app you use to access Meta Verified, may include a broad set of measures, e.g. profile visits, post engagement, status views and/or, subject to applicable law, number of message conversations.",
    },
    {
        question: "Do my Meta Verified benefits extend to other accounts in my business portfolio?",
        answer: "Your Meta Verified benefits (including support access) only apply to your subscribed Facebook Page, Instagram account or WhatsApp phone number.",
    },
];

const FaqMeta = () => {

    const [active, setActive] = useState<number | null>(0);

    return (
        <div className='max-w-[1175px] mx-auto mt-20 mb-[80px] px-6'>
            <p className='text-[32px] mb-3'>FAQ</p>
            <p className='text-[18px] font-[500] mb-10'>For more, visit our Help Centre (<Link className='text-[#0064E0] underline decoration-[#cbd2d9]' href="https://www.facebook.com/business/help/2876154822522394">Instagram and Facebook</Link>; <Link className='text-[#0064E0] underline decoration-[#cbd2d9]' href="https://faq.whatsapp.com/3872729742954601">WhatsApp</Link>).</p>

            <div className="divide-y border-t border-b">
                {faqData.map((item, index) => {
                    const open = active === index;

                    return (
                        <div key={index}>
                            <button
                                onClick={() => setActive(open ? null : index)}
                                className="py-8 w-full flex items-center justify-between py-6 text-left text-lg font-medium"
                            >
                                <span className="md:text-[24px] text-[20px]">{item.question}</span>
                                <span className={`transition-transform ${open ? "rotate-180" : ""}`}>
                                    <img src="/images/meta/ic_arrow.svg" alt="arrow" className='md:w-[24px] w-[20px] md:h-[24px] h-[20px]' />
                                </span>
                            </button>

                            <div className={`grid transition-all duration-300 linear-in-out ${open? "max-h-40 grid-rows-[1fr] opacity-100": "max-h-0 grid-rows-[0fr] opacity-0"}`}>
                                <div className="md:text-[18px] text-[16px] overflow-hidden text-gray-600 pb-8 leading-relaxed">
                                    {item.answer}
                                </div>
                            </div>
                        </div>
                    );
                })}
            </div>
        </div>
    )
}

export default FaqMeta
